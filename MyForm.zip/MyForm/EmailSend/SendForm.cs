using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using MailKit.Net.Smtp;
using MimeKit;

namespace EmailSend
{
    public partial class SendForm : Form
    {
        public SendForm()
        {
            InitializeComponent();
        }

        private void SendForm_Load(object sender, EventArgs e)
        {
            // Add some sample users to the DataGridView. The user can edit or add rows.
            if (dgvUsers.Rows.Count == 0 || (dgvUsers.Rows.Count == 1 && dgvUsers.Rows[0].IsNewRow))
            {
                dgvUsers.Rows.Add("Іван Петров", "ivan.petrov@example.com");
                dgvUsers.Rows.Add("Марія Іванова", "maria.ivanova@example.com");
            }
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            //Діалог для вибору файлу
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string file = ofd.FileName;
                txtPath.Text = file;
            }

        }

        async Task MySendEmail(string subject, string body, string file, string to, string toName = null)
        {
            //пароль для додатку
            string password = "Gab0HRd5oyUYa5oa"; //пароль у кожного свій
            string smtpServer = "smtp.ukr.net";
            int port = 2525;
            string from = "super.novakvova@ukr.net"; //користувач у кожного свій
            string username = from;

            var emailMessage = new MimeMessage();
            emailMessage.From.Add(new MailboxAddress(from));

            if (!string.IsNullOrWhiteSpace(toName))
                emailMessage.To.Add(new MailboxAddress(toName, to));
            else
                emailMessage.To.Add(new MailboxAddress(to));

            emailMessage.Subject = subject;

            var multipart = new Multipart("mixed");

            var bodyHtml = new TextPart("html") { Text = body };
            multipart.Add(bodyHtml);

            if (!string.IsNullOrWhiteSpace(file) && File.Exists(file))
            {
                try
                {
                    var attachment = new MimePart(System.Net.Mime.MediaTypeNames.Application.Octet.Split('/')[0], "octet-stream")
                    {
                        FileName = Path.GetFileName(file),
                        Content = new MimeContent(File.OpenRead(file))
                    };
                    multipart.Add(attachment);
                }
                catch
                {
                    // Ignore attachment errors and send the message without the file
                }
            }

            emailMessage.Body = multipart;

            using var client = new SmtpClient();
            try
            {
                await client.ConnectAsync(smtpServer, port, true);
                await client.AuthenticateAsync(username, password);
                await client.SendAsync(emailMessage);
                await client.DisconnectAsync(true);
            }
            catch (Exception ex)
            {
                throw new Exception($"Error sending to {to}: {ex.Message}", ex);
            }
        }

        private async void btnSend_Click(object sender, EventArgs e)
        {
            string subject = txtSubject.Text;
            string body = txtBody.Text;
            string file = txtPath.Text;

            var failed = new List<string>();
            var sent = new List<string>();

            // Iterate rows and send to each non-empty email
            foreach (DataGridViewRow row in dgvUsers.Rows)
            {
                if (row.IsNewRow)
                    continue;

                var nameObj = row.Cells[0].Value;
                var emailObj = row.Cells[1].Value;

                string name = nameObj?.ToString()?.Trim();
                string email = emailObj?.ToString()?.Trim();

                if (string.IsNullOrWhiteSpace(email))
                    continue;

                // Simple validation
                if (!email.Contains("@"))
                {
                    failed.Add($"{name ?? "(no name)"} <{email}> (invalid)");
                    continue;
                }

                try
                {
                    await MySendEmail(subject, body, file, email, name);
                    sent.Add($"{name ?? "(no name)"} <{email}>");
                }
                catch (Exception ex)
                {
                    failed.Add($"{name ?? "(no name)"} <{email}>: {ex.Message}");
                }
            }

            var msg = new System.Text.StringBuilder();
            msg.AppendLine($"Надіслано: {sent.Count}");
            msg.AppendLine($"Не вдалося: {failed.Count}");
            if (failed.Count > 0)
            {
                msg.AppendLine();
                msg.AppendLine("Помилки:");
                foreach (var f in failed)
                    msg.AppendLine(f);
            }

            MessageBox.Show(msg.ToString(), "Результат відправки");
        }
    }
}
