﻿namespace EmailSend
{
    partial class SendForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtSubject = new TextBox();
            label3 = new Label();
            txtBody = new TextBox();
            label4 = new Label();
            txtPath = new TextBox();
            btnSelect = new Button();
            btnCancel = new Button();
            btnSend = new Button();
            dgvUsers = new DataGridView();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)dgvUsers).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(433, 23);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(301, 51);
            label1.TabIndex = 0;
            label1.Text = "Відпрака листа";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label2.ForeColor = Color.Blue;
            label2.Location = new Point(27, 111);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(181, 45);
            label2.TabIndex = 0;
            label2.Text = "Тема листа";
            // 
            // txtSubject
            // 
            txtSubject.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            txtSubject.Location = new Point(285, 111);
            txtSubject.Margin = new Padding(4, 4, 4, 4);
            txtSubject.Name = "txtSubject";
            txtSubject.Size = new Size(789, 50);
            txtSubject.TabIndex = 1;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label3.ForeColor = Color.Blue;
            label3.Location = new Point(27, 189);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(81, 45);
            label3.TabIndex = 0;
            label3.Text = "Тіло";
            // 
            // txtBody
            // 
            txtBody.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            txtBody.Location = new Point(285, 189);
            txtBody.Margin = new Padding(4, 4, 4, 4);
            txtBody.Multiline = true;
            txtBody.Name = "txtBody";
            txtBody.Size = new Size(789, 250);
            txtBody.TabIndex = 2;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            label4.ForeColor = Color.Blue;
            label4.Location = new Point(27, 475);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(230, 45);
            label4.TabIndex = 0;
            label4.Text = "Файл до листа";
            // 
            // txtPath
            // 
            txtPath.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 204);
            txtPath.Location = new Point(285, 466);
            txtPath.Margin = new Padding(4, 4, 4, 4);
            txtPath.Name = "txtPath";
            txtPath.Size = new Size(789, 50);
            txtPath.TabIndex = 4;
            // 
            // btnSelect
            // 
            btnSelect.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point, 204);
            btnSelect.ForeColor = Color.Red;
            btnSelect.Location = new Point(27, 370);
            btnSelect.Margin = new Padding(4, 4, 4, 4);
            btnSelect.Name = "btnSelect";
            btnSelect.Size = new Size(105, 70);
            btnSelect.TabIndex = 3;
            btnSelect.Text = "🗃️";
            btnSelect.UseVisualStyleBackColor = true;
            btnSelect.Click += btnSelect_Click;
            // 
            // btnCancel
            // 
            btnCancel.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            btnCancel.Location = new Point(792, 642);
            btnCancel.Margin = new Padding(4, 4, 4, 4);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(208, 67);
            btnCancel.TabIndex = 6;
            btnCancel.Text = "Скасувати";
            btnCancel.UseVisualStyleBackColor = true;
            // 
            // btnSend
            // 
            btnSend.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 204);
            btnSend.ForeColor = Color.Blue;
            btnSend.Location = new Point(285, 642);
            btnSend.Margin = new Padding(4, 4, 4, 4);
            btnSend.Name = "btnSend";
            btnSend.Size = new Size(208, 67);
            btnSend.TabIndex = 5;
            btnSend.Text = "Надіслати";
            btnSend.UseVisualStyleBackColor = true;
            btnSend.Click += btnSend_Click;
            // 
            // dgvUsers
            // 
            dgvUsers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvUsers.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2 });
            dgvUsers.Location = new Point(1149, 36);
            dgvUsers.Margin = new Padding(4, 4, 4, 4);
            dgvUsers.Name = "dgvUsers";
            dgvUsers.RowHeadersWidth = 82;
            dgvUsers.Size = new Size(781, 673);
            dgvUsers.TabIndex = 7;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.MinimumWidth = 10;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.Width = 200;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.MinimumWidth = 10;
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            dataGridViewTextBoxColumn2.Width = 200;
            // 
            // SendForm
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1965, 915);
            Controls.Add(dgvUsers);
            Controls.Add(btnSend);
            Controls.Add(btnCancel);
            Controls.Add(btnSelect);
            Controls.Add(txtBody);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(txtPath);
            Controls.Add(txtSubject);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(4, 4, 4, 4);
            Name = "SendForm";
            Text = "Надсилання листа";
            Load += SendForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgvUsers).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtSubject;
        private Label label3;
        private TextBox txtBody;
        private Label label4;
        private TextBox txtPath;
        private Button btnSelect;
        private Button btnCancel;
        private Button btnSend;
        private DataGridView dgvUsers;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    }
}
